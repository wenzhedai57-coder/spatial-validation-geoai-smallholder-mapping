# CEA R2 rubber rescreen v2 clean audit bundle

This bundle preserves the completed R2 rubber-rescreened V2 label table and the audit outputs generated from it.

Use note:

- This is a blind second-reader visual audit, not geotagged field truth.
- Rows marked `unreadable` are preserved and excluded from readable-pair agreement denominators.
- The V2 table should be described as a targeted rubber-rescreen sensitivity, not as a new independent field-validation dataset.
- The audit reports compare V2 with the earlier completed R2 table and record all changed rows.
