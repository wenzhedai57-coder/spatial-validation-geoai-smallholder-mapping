# CEA Second-Round Human Label Audit

This package contains the completed blind second-reader label table and its completion provenance.

Annotator code: `R2`

Human reader note: `R2` is a human second-reader code. It is not an AI system name.

Files:

- `SECOND_READER_BLIND_LABELS_R2_COMPLETED_20260620.csv`
- `SECOND_READER_BLIND_LABELS_R2_COMPLETION_PROVENANCE_20260620.json`

Allowed labels:

- `oil_palm`
- `rubber`
- `paddy`
- `other_agri`
- `forest`
- `builtup_other`
- `unreadable`

Use gate:

- Keep this package with the kappa CSV/JSON outputs generated from the locked reference file.
- Do not treat `unreadable` rows as invented labels.
- Do not claim field-truth validation; this is a blind second-reader visual audit.
