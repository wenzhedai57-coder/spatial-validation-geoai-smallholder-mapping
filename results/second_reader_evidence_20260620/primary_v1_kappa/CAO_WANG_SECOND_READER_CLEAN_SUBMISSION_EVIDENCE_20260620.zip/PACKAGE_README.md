﻿# Cao Wang second-reader clean evidence bundle

Contents:

- cleaned_package/: completed R2 blind label table and portable completion provenance.
- kappa_results_cleaned/: kappa outputs and row/class-level detail tables generated from the locked reference file and the completed R2 label table.

Use note:

- The completed CSV labels were not changed during cleaning.
- Rows marked unreadable were preserved as unreadable and not forced into a class.
- This is a second-reader visual audit, not field-truth validation.
